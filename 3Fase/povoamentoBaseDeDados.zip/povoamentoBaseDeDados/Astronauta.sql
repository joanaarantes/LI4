
USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Astronauta
(id_Astronauta, NomeAstronauta, Cargo)
VALUES
(1,'Maria Helena', 'gestor_missao'),
(2,'Pedro Cunha', 'especialista_rochas'),
(3,'Pedro Alves', 'médico'),
(4,'Joana Arantes', 'cartografo'),
(5,'Daniel Malhadas', 'geólogo'),
(6,'Jessica Pereira', 'gestor_missao'),
(7,'Rita Rua', 'geologo'),
(8,'Susana Mendes', 'cartografo'),
(9,'Maria Pereira', 'especialista_rochas'),
(10,'Marcos Pereira', 'medico'),
(11,'Laura Mendes', 'gestor_missao');

SET SQL_SAFE_UPDATES = 1;