USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Percurso
(id_Percurso)
VALUES
(1),
(2);


SET SQL_SAFE_UPDATES = 1;