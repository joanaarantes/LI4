
USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Astro
(id_Atividade, Descricao, id_Missao)
VALUES
(1,'Cartografar percurco Axc1', 1),
(2,'Recolha de Rochas e mineirais 1', 2),
(3, 'Exploracao e mapeamento percurso Acx2', 3),
(4, 'Recolha de mineirais tipo C2', 4);

SET SQL_SAFE_UPDATES = 1;