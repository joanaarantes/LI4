
USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Cadernodenotas
(id_Caderno)
VALUES
(1),
(2);

SET SQL_SAFE_UPDATES = 1;