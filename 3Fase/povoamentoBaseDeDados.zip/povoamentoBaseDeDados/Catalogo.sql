USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Catalogo
(id_Catalogo, NomeCatalogo)
VALUES
(1,'Rochas e Minerais');

SET SQL_SAFE_UPDATES = 1;