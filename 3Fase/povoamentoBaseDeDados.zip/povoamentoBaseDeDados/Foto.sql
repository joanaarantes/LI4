USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Foto
(id_Foto, nomeMineral, Foto, id_Catalogo)
VALUES
(1,'basalto1','xbdssoxsd',1),
(2,'anortosito10','xbsodsxsd',1),
(3,'basalto2','adxabsoxsd',1),
(4,'basalto3','2dsxbsoxsd',1),
(5,'anortosito11','xbdsdsoxsd',1),
(6,'basalto4','2xadbsoxsd',1),
(7,'anortosito1','ds3xbsoxsd',1);

SET SQL_SAFE_UPDATES = 1;