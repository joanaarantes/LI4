
USE ---;
SET SQL_SAFE_UPDATES = 0;

INSERT INTO Astro
(id_Astro, NomeAstro)
VALUES
(1,'Lua'),
(2,'Marte');

SET SQL_SAFE_UPDATES = 1;